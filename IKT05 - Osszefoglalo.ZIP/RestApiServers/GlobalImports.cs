﻿global using Microsoft.AspNetCore.Mvc;
global using Swashbuckle.AspNetCore.Annotations;
global using System.ComponentModel.DataAnnotations;
global using System.Net;