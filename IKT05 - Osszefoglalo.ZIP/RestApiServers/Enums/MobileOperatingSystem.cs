﻿public enum MobileOperatingSystem: byte
{
    iOS = 0,
    Android = 1,
    Windows = 2
}
