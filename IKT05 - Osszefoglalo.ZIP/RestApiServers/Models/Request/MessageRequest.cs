﻿public class MessageRequest
{
    public string Content { get; set; }

    public MobileOperatingSystem System { get; set; }
}
